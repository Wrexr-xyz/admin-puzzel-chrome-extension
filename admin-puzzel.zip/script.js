let element = document.getElementById("js-custom-element");
element.innerHTML = '<img src="https://i.imgur.com/5Vj5tnu.png"/><div class="iframediv"><iframe src="https://admin.puzzel.com/admin/Home" scrolling="no"></iframe></div>';
